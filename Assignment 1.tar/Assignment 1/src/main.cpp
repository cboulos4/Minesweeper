/**
* Author: Christopher Boulos (cboulos4) (251267786)
* Date: 5/2/2025
*
* main.cpp:
* This file first initializes the QApplication and the GridWindow, then it enters the application's event loop
*/

#include "main.h"

int main(int argc, char *argv[]) {

    QApplication app(argc, argv); // Initializes the Qt application
    GridWindow window; // Creates the main window 
    window.show(); // Shows the main window (Grid Window)
    return app.exec(); 
}
