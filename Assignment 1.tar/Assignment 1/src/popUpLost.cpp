/**
* Author: Christopher Boulos (cboulos4) (251267786)
* Date: 5/2/2025
*
* popUpLost.cpp:
* This file implements the popup window's UI that appears when a game is lost (when a mine is clicked) 
* It also handles the restart and exit buttons in the popup, connecting the button signals to their respective slots, and emitting signals for restarting or exiting the game.
*/

#include "popUpLost.h"

/**
* PopUpLost():
* A constructor method that sets up the loss dialog popup window.
* It initializes the dialog, sets the message, and adds the restart and exit buttons. It also initializes a parent widget (if there is any)
* It also connects the restart and exit buttons to private slots, which then emit signals to the "GridLogic" class, where they are then handled there
*
* @param parent The parent widget, defaulted to nullptr.
*/
PopUpLost::PopUpLost(QWidget *parent) : QDialog(parent) {
    layout = new QVBoxLayout(this); // Creates an instance of a vertical box layout 

    // Sets the popup windows attributes
    setWindowTitle("Uh Oh! Game Over...");
    message = new QLabel("You have hit a mine and exploded!!", this); // Creates an instance of a Label containing a message
    restartButton = new QPushButton("Try Again?", this); // Creates an instance of a QPushButton with the text "Try Again?". This is for restarting a game when clicked
    exitButton = new QPushButton("Exit", this); // Creates an instance of a QPushButton with the text "Exit". This is closing and exiting a game when clicked

    // Adds the message, restart button, and exit button widgets to the vertical box layout
    layout->addWidget(message);
    layout->addWidget(restartButton);
    layout->addWidget(exitButton);
    setLayout(layout);

    // Connects the "clicked" signal of the "restartButton" to the "onRestartButtonClicked" slot, which will emit the "restartGame" signal when clicked
    connect(restartButton, &QPushButton::clicked, this, &PopUpLost::onRestartButtonClicked);

    // Connects the "clicked" signal of the "exitButton" to the "onExitButtonClicked" slot, which will emit the "exitGame" signal when clicked
    connect(exitButton, &QPushButton::clicked, this, &PopUpLost::onExitButtonClicked);
}

/**
* onRestartButtonClicked():
* A slot that is accessed when the "Try Again?" button in the pop up window that appears after losing is clicked.
* It emits a "restartGame" signal to the "GridLogic" class, where it can be handled, and closes the pop up window.
*/
void PopUpLost::onRestartButtonClicked() {
    emit restartGame();  // Emits a signal for restarting the game
    close();  // Closes the popup window
}

/**
* onExitButtonClicked():
* A slot that is accessed when the "Exit" button in the pop up window that appears after losing is clicked.
* It emits an "exitGame" signal to the "GridLogic" class, where it can be handled, and closes the pop up window.
*/
void PopUpLost::onExitButtonClicked() {
    emit exitGame();  // Emit signal for exiting
    close();  // Closes the popup window
}

/**
* ~PopUpLost():
* A destructor used to clean up dynamically allocated memory
*/
PopUpLost::~PopUpLost(){}
