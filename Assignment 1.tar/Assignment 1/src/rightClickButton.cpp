/**
* Author: Christopher Boulos (cboulos4) (251267786)
* Date: 5/2/2025
*
* RightClickButton.cpp:
* This file implements the custom "RightClickButton" class, which handles right click and left click events differently. It emits signals based on which mouse button was used
*/

#include "rightClickButton.h"

/**
* RightClickButton():
* A constructor method that initializes the button and the parent widget (if there is any)
*
* @param parent The parent widget, defaulted to nullptr.
*/
RightClickButton::RightClickButton(QWidget *parent)
    : QPushButton(parent) {}

/**
* mouseReleaseEvent():
* Event handler for mouse release events.
* This method overrides the default mouse release event to emit custom signals based on the button that was pressed (right or left).
*
* @param e The mouse event, which contains information about the mouse release.
*/
void RightClickButton::mouseReleaseEvent(QMouseEvent *e) {
    
    // Checks if the right mouse button was released
    if (e->button() == Qt::RightButton) {
        emit rightClicked(); // Emits the "rightClicked" signal, indicating that a right click was used
    } 
    
    // Checks if the left mouse button was released
    else if (e->button() == Qt::LeftButton) {
        emit clicked(e); // Emits the "clicked" signal (overloaded), indicating that a left click was used
    }

    QPushButton::mouseReleaseEvent(e); // Calls the base class to ensure default QPushButton behaviour
}

/**
* ~RightClickButton():
* A destructor used to clean up dynamically allocated memory
*/
RightClickButton::~RightClickButton() {}
