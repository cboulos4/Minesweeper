/**
* Author: Christopher Boulos (cboulos4) (251267786)
* Date: 5/2/2025
*
* gridWindow.cpp:
* This file handles the Minesweeper grid's UI. It initializes a 16x30 grid of QPushButtonssetting their "buttonType" property to "default", indicating the tiles do not contain mines. 
* It also assigns 99 random tiles with the property type of "mine", indicating that the tile contains a mine.
* It handles both the left and right clicking events on the tiles.
*/

#include "gridWindow.h"
#include "gridLogic.h"

/**
* GridWindow():
* A constructor method that sets up the minesweeper UI grid (GridWindow) with QPushButtons in a 16x30 grid. It also initializes a parent widget (if there is any)
* It also handles button creation, layout setup, and event handling and connections for left and right clicking buttons
*
* @param parent The parent widget, which is defaulted to nullptr.
*/
GridWindow::GridWindow(QWidget *parent)
    : QMainWindow(parent), NUM_OF_ROWS(16), NUM_OF_COLUMNS(30)
{
    centralWidget = new QWidget(this); // Creates an instance of a widget, which will act as a central widget that holds the 16x30 minesweeper grid layout
    gridLayout = new QGridLayout(centralWidget); // Creates an instance of a grid layout which will hold all the QPushButtons
    
    setCentralWidget(centralWidget); // Sets the central widget of the main window to the "centralWidget" instance
    centralWidget->setLayout(gridLayout);
    buttons.resize(NUM_OF_ROWS);

    // Creates and places buttons in the grid:
    for (int i = 0; i < NUM_OF_ROWS; i++) {
        buttons[i].resize(NUM_OF_COLUMNS);

        for (int j = 0; j < NUM_OF_COLUMNS; j++) {
            RightClickButton *button = new RightClickButton(); // Creates a new button for the grid with both left and right click event handling
            
            buttons[i][j] = button; // Assigns the button to the grid

            // Sets the button's size, icon, icon size, and sets its property type to "default"
            button->setFixedSize(25, 25);
            button->setIcon(QIcon("../Assignment 1/assets/minesweeper-square.png"));
            button->setIconSize(QSize(25, 25));
            button->setProperty("buttonType", "default"); 
            
            gridLayout->addWidget(button, i, j); // Adds the button to the grid
            
            // Left-click connection: It emits the "buttonClicked" signal when the button is left clicked. It passes the clicked button's row and column index.
            connect(button, &RightClickButton::clicked, [this, i, j]() {
                emit buttonClicked(i, j);
            });

            // Right-click connection: It emits the "buttonClicked" signal when the button is right clicked. It passes the clicked button's row and column index.
            connect(button, &RightClickButton::rightClicked, [this, i, j]() {
                emit buttonClicked(i, j);
            });
        }
    }

    setNumOfMines(99); // Initializes the variable "numOfTiles" to 99 before calling "setMineTiles()"
    setMineTiles(numOfMines); // Calls the function "setMineTiles()", which assigns 99 random buttons in the minesweeper grid as mines

    // Game logic initialization and signal to slot connection:
    logic = new GridLogic(this); // Initializes the games logic by creating an instance of the class "GridLogic", which contains all the logic of the minesweeper game
    
    // Connects the "buttonClicked" signal from the "GridWindow" class to the "handleButtonClick" in the "GridLogic" class, which allows communication between the grid's UI and the grid's logic whenever a button is pressed on the grid
    connect(this, &GridWindow::buttonClicked, logic, &GridLogic::handleButtonClick); 
    
    // Sets the window's properties:
    setWindowTitle("Minesweeper");
    gridLayout->setHorizontalSpacing(0); // Keeps the buttons stuck together horizontally on the grid
    gridLayout->setVerticalSpacing(0); // Keeps the buttons stuck together vertically on the grid
}

/**
* setMineTiles():
* A function that randomly assigns 99 button tiles in the grid with the property type of "mine", overwriting their previous property type of "default", indicating that they now contain mines
*
* @param numOfMines The total number of tiles that will be assigned as mines
*/
void GridWindow::setMineTiles(int numOfMines) {
    srand(time(NULL)); // Initializes a random seed based on the current time of NULL

    // Assigns 99 random tiles in the grid with a property of "mine"
    while (numOfMines != 0) {

        // Picks a random row and column index
        randomRow = getRandomRow();
        randomColumn = getRandomColumn();

        // Gets a random button from the grid using the random row and column index picked 
        QPushButton *button = buttons[randomRow][randomColumn];

        // Checks if the current button already has a mine by checking if its property type has already been set to "mine"
        if (button->property("buttonType").toString() != "mine") {
            
            button->setProperty("buttonType", "mine"); // Sets the property of the button to "mine"
            numOfMines--; // Decrement the variable "numOfMines" for each button successfully set to "mine" 
        }
    }
}


/**
* getButtons():
* A Getter function that returns the 2D QVector array holding the QPushButtons pointers of the minesweeper grid
*
* @return buttons A constant reference to the 2D array containing the QPushButton pointers of the grid
*/
const QVector<QVector<QPushButton*>>& GridWindow::getButtons() const {
    return buttons;
}

/**
* getNumOfRows():
* A Getter method that returns the number of columns in the minesweeper grid.
*
* @return NUM_OF_ROWS The number of rows in the minesweeper grid
*/
int GridWindow::getNumOfRows() const {
    return NUM_OF_ROWS;
}

/**
* getNumOfColumns():
* A Getter method that returns the number of columns in the minesweeper grid.
*
* @return NUM_OF_COLUMNS The number of columns in the minesweeper grid
*/
int GridWindow::getNumOfColumns() const {
    return NUM_OF_COLUMNS;
}

/**
* getNumOfMines():
* A Getter method that returns the total number of tiles containing mines in the minesweeper grid.
*
* @return numOfMines The number of tiles containing mines in the minesweeper grid
*/
int GridWindow::getNumOfMines() {
    return numOfMines;
}

/**
* setNumOfMines():
* A Setter method that sets the total number of mines on the grid.
*
* @param newNumOfMines The "new" number of mines to place on the grid
*/
void GridWindow::setNumOfMines(int newNumOfMines){
    numOfMines = newNumOfMines;
}

/**
* getRandomRow():
* A getter function that returns a random row index
*
* @return returns a random row index
*/
int GridWindow::getRandomRow() {
    return rand() % NUM_OF_ROWS;
}

/**
* getRandomColumn():
* A getter function that returns a random column index
*
* @return returns a random column index
*/
int GridWindow::getRandomColumn() {
    return rand() % NUM_OF_COLUMNS;
}

/**
* ~GridWindow():
* A Destructor method that cleans up the allocated resources
*/
GridWindow::~GridWindow() {

    // Deletes each button in the minesweeper grid
    for (int i = 0; i < 16; i++) {

        for (int j = 0; j < 30; j++) {
            delete buttons[i][j];
        }
    }

    delete gridLayout; // Deletes the grid layout
    delete centralWidget; // Deletes the central widget holding the grid of buttons
}
