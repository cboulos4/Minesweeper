/**
* Author: Christopher Boulos (cboulos4) (251267786)
* Date: 5/2/2025
*
* gridLogic.cpp:
* This file implementation handles the Minesweeper grid's logic.
* It handles button clicks from the signals sent from the "GridWindow", "PopUpLost", and "PopUpWon" classes.
* It also checks for adjacent mines, reveals tiles, and handles game outcomes (win or loss).
*
* It utilizes Depth First Search (DFS) to recursively check if neighbouring button tiles of the clicked button tile have adjacent tiles that contain mines, and then sets the button tile's property type to "revealed", indicating that that button tile has been explored
* For tiles that have no adjacent tiles containing mines, it sets their icon to a blank tile, indicating the tile has no adjacent tiles containing mines.
* For tiles that do have adjacent tiles containing mines, it sets their icon to the number of adjacent tiles containing mines and stops recursively checking in that direction.
* It only checks tiles that: 
* 1. Do not have the property type of "revealed"
* 2. Do not have the property type of "mine"
*/

#include "gridLogic.h"
#include "gridWindow.h"

/**
* GridLogic():
* A constructor method that constructs a GridLogic object.
* The constructor takes a pointer to an existing GridWindow instance instead of creating a new one to prevent segmentation fault, the creation of a new instance, or double deletion
* It initializes the necessary variables to carry out the grid's logic. It also initializes a parent widget (if there is any)
*
* @param gridWindowPtr A pointer to the GridWindow instance.
* @param parent The parent widget, which is defaulted to nullptr
*/
GridLogic::GridLogic(GridWindow *gridWindowPtr, QObject *parent)
    : QObject(parent), gridWindow(gridWindowPtr)
{
    // Gets the buttons grid and game parameters from the GridWindow class using its getter functions
    buttons = gridWindow->getButtons();
    numOfRows = gridWindow->getNumOfRows();
    numOfColumns = gridWindow->getNumOfColumns();
    numOfMines = gridWindow->getNumOfMines(); // A copy of the "GridWindow" class's variable. A copy is made since the "GridWindow" class's "numOfMines" variable gets decremented to 0 and it needs to be set to its initialized value before restarting a game

    // Initializes "numOfAdjacentMines" to 0 by passing 0 through its setter function.
    setNumOfAdjacentMines(0);
    numOfAdjacentMines = getNumOfAdjacentMines();

    // Creates an instance of a popup window that appears when losing and a popup window that appears when winning
    popUpLost = new PopUpLost(gridWindow);
    popUpWon = new PopUpWon(gridWindow);

    // Connects the signals sent from clicking the "Try Again?" or "Exit" buttons on the pop up window's UI located in the "PopUpLost" class to the public slots, "restartGame" and "exitGame", of the "GridLogic" class respectively
    connect(popUpLost, &PopUpLost::restartGame, this, &GridLogic::restartGame);
    connect(popUpLost, &PopUpLost::exitGame, this, &GridLogic::exitGame);

    // Connects the signals sent from clicking the "Try Again?" or "Exit" buttons on the pop up window's UI located in the "PopUpWon" class to the public slots, "restartGame" and "exitGame", of the "GridLogic" class respectively
    connect(popUpWon, &PopUpWon::restartGame, this, &GridLogic::restartGame);
    connect(popUpWon, &PopUpWon::exitGame, this, &GridLogic::exitGame);
}

/**
* handleButtonClick():
* This function handles the button clicking events from the GridWindow class whenever the player left clicks or right clicks a button tile
* If the player clicks on a mine, it will reveal all the hidden mines on the grid and triggers the game over pop up
* If the player clicks on a non-mine tile, it will recursively reveal adjacent tiles until a tile with adjacent mine tiles, or a mine tile. For every non-mine tile that is clicked, it will always check if all the non mine tiles have been revealed
*
* @param row The row index of the clicked button
* @param col The column index of the clicked button
*/
void GridLogic::handleButtonClick(int row, int col) {
    clickedButton = buttons[row][col]; // Gets the button tile that was just clicked on the grid's UI

    // Loss:
    // Checks if the button tile that was clicked is a mine by checking if its property type had been set to "mine" 
    if (clickedButton->property("buttonType").toString() == "mine") {

        revealMines(); // Calls the "revealMines()" function, which reveals all the hidden mine tile's locations

        // Sets the icon of the button tile that was just clicked to a red mine icon, which indicates which mine on the grid the player clicked
        clickedButton->setIcon(QIcon("../Assignment 1/assets/mine_red.png"));
        clickedButton->setIconSize(QSize(25, 25)); 
        
        popUpLost->exec(); // Displays the "PopUpLost" class's pop up window and blocks execution until the user presses either button presented on the window
    }

    // Win:
    // Checks if the button tile that was clicked is not a mine by checking if its property type had not been set to "mine" and stayed as "default"
    else if (clickedButton->property("buttonType").toString() == "default"){
        
        int numOfAdjacentMines = totalAdjacentMines(row, col); // Gets the total number of adjacent tiles that contain mines
        setNumOfAdjacentMinesIcon(row, col, numOfAdjacentMines, clickedButton); // Depending on how many adjacent tiles of the clicked button tile contains mines, "setNumOfAdjacentMinesIcon()" sets the clicked button tile's icon to that number. If it is 0, it will call "gridDFS()""
        
        // If all non mine tiles have been revealed:
        if (areAllNonMineRevealed()){

            for (int i = 0; i < numOfRows; i++){
                for (int j = 0; j < numOfColumns; j++){

                    // Reveals all the mines' locations by setting their icon to a flag tile icon since the player has won
                    if (buttons[i][j]->property("buttonType").toString() == "mine") {
                        buttons[i][j]->setIcon(QIcon("../Assignment 1/assets/flag_tile.png"));
                        buttons[i][j]->setIconSize(QSize(25, 25));
                    }
                }
            }

            popUpWon->exec(); // Displays the "PopUpWon" class's pop up window and blocks execution until the user presses either button presented on the window
        }
    }
}

/**
* totalAdjacentMines():
* Checks if each tile adjacent to the clicked button tile contains a mine. It increments the "numOfAdjacentMines" variable by 1 for each adjacent tile that contains a mine
* 
* @param row The clicked button's row index
* @param col The clicked button's column index
* @return numOfAdjacentMines The total number of adjacent tiles containing mines the clicked button tile has
*/
int GridLogic::totalAdjacentMines(int row, int col){
    setNumOfAdjacentMines(0); // Sets the variable "numOfAdjacentMines" to 0 before checking each tile's adjacent tiles

    // Up: checks if the tile above the clicked tile has its property type set to "mine", which indicates that it contains a mine
    if (row - 1 >= 0  && buttons[row - 1][col]->property("buttonType").toString() == "mine"){
        numOfAdjacentMines++;
    }
    
    // Down: checks if the tile below the clicked tile has its property type set to "mine", which indicates that it contains a mine
    if (row + 1 < numOfRows && buttons[row + 1][col]->property("buttonType").toString() == "mine") {
        numOfAdjacentMines++;
    }

    // Left: checks if the tile to the left of the clicked tile has its property type set to "mine", which indicates that it contains a mine
    if (col - 1 >= 0 && buttons[row][col - 1]->property("buttonType").toString() == "mine") {
        numOfAdjacentMines++;
    }

    // Right: checks if the tile to the right of the clicked tile has its property type set to "mine", which indicates that it contains a mine
    if (col + 1 < numOfColumns && buttons[row][col + 1]->property("buttonType").toString() == "mine") {
        numOfAdjacentMines++;
    }

    // Top Left: checks if the tile to the top left of the clicked tile has its property type set to "mine", which indicates that it contains a mine
    if (row - 1 >= 0 && col - 1 >= 0 && buttons[row - 1][col - 1]->property("buttonType").toString() == "mine"){
        numOfAdjacentMines++;
    }

    // Top Right: checks if the tile to the top right of the clicked tile has its property type set to "mine", which indicates that it contains a mine
    if (row - 1 >= 0 && col + 1 < numOfColumns && buttons[row - 1][col + 1]->property("buttonType").toString() == "mine"){
        numOfAdjacentMines++;
    }

    // Bottom left: checks if the tile to the bottom left of the clicked tile has its property type set to "mine", which indicates that it contains a mine
    if (row + 1 < numOfRows && col - 1 >= 0 && buttons[row + 1][col - 1]->property("buttonType").toString() == "mine") {
        numOfAdjacentMines++;
    }

    // Bottom right: checks if the tile to the bottom right of the clicked tile has its property type set to "mine", which indicates that it contains a mine
    if (row + 1 < numOfRows && col + 1 < numOfColumns && buttons[row + 1][col + 1]->property("buttonType").toString() == "mine") {
        numOfAdjacentMines++;
    }

    return numOfAdjacentMines;
}

/**
* setNumOfAdjacentMinesIcon():
* A funtion that sets the clicked button tile's icon to the number of adjacent tiles containing mines that it has
*
* @param row The row index of the clicked button
* @param col The column index of the clicked button
* @param numOfAdjacentMines The total number of adjacent mines the clicked button has
* @param button A pointer to the clicked button
*/
void GridLogic::setNumOfAdjacentMinesIcon(int row, int col, int numOfAdjacentMines, QPushButton* button){
    
    // Setting the clicked button's icon to the number of adjacent mines:
    // Has no adjacent mines
    if (numOfAdjacentMines == 0){
        button->setIcon(QIcon("../Assignment 1/assets/blank.png"));  
        gridDFS(row, col); // Calls "gridDFS()" whenever the clicked button has no adjacent mines 
    }        

    // Checks to see if the clicked button has 1 adjacent mine 
    else if (numOfAdjacentMines == 1){
        button->setIcon(QIcon("../Assignment 1/assets/1.png"));
    }

    // Checks to see if the clicked button has 2 adjacent mines
    else if (numOfAdjacentMines == 2){
        button->setIcon(QIcon("../Assignment 1/assets/2.png"));
    }

    // Checks to see if the clicked button has 3 adjacent mines
    else if (numOfAdjacentMines == 3){
        button->setIcon(QIcon("../Assignment 1/assets/3.png"));
    }

    // Checks to see if the clicked button has 4 adjacent mines
    else if (numOfAdjacentMines == 4){
        button->setIcon(QIcon("../Assignment 1/assets/4.png"));
    }

    // Checks to see if the clicked button has 5 adjacent mines
    else if (numOfAdjacentMines == 5){
        button->setIcon(QIcon("../Assignment 1/assets/5.png"));
    }

    // Checks to see if the clicked button has 6 adjacent mines
    else if (numOfAdjacentMines == 6){
        button->setIcon(QIcon("../Assignment 1/assets/6.png"));
    }

    // Checks to see if the clicked button has 7 adjacent mines
    else if (numOfAdjacentMines == 7){
        button->setIcon(QIcon("../Assignment 1/assets/7.png"));
    }

    // Checks to see if the clicked button has 8 adjacent mines
    else if (numOfAdjacentMines == 8){
        button->setIcon(QIcon("../Assignment 1/assets/8.png"));
    }

    // Sets its icon size to 25x25 and its property type to "revealed", indicating that the tile has been revealed
    button->setIconSize(QSize(25, 25));   
    button->setProperty("buttonType", "revealed"); 
}

/**
* gridDFS():
* It utilizes Depth First Search (DFS) to recursively check neighbouring button tiles of the clicked button tile, revealing them if they meet these conditions:
* 1. The tile is within bounds
* 2. The tile is not already revealed
* 3. The tile is not a mine
*
* For tiles that have no adjacent tiles containing mines, it sets their icon to a blank tile, indicating the tile has no adjacent tiles containing mines. It then continues revealing its neighbouring tiles.
* For tiles that do have adjacent tiles containing mines, it sets their icon to the number of adjacent tiles containing mines and stops any more recursion in that direction.
* 
* @param row The current button tile's row index
* @param col The current button tile's column index
*/
void GridLogic::gridDFS(int row, int col) {
    // Base case: stops recursing in that direction if the current tile is out of bounds
    if (row < 0 || row >= numOfRows || col < 0 || col >= numOfColumns) {
        return;
    }

    QPushButton *currentButton = buttons[row][col]; // The current button being explored

    // Base case: stops recursing in the that direction of the current tile is a mine or has been revealed (checks if its property type is "mine" or "revealed")
    if (currentButton->property("buttonType").toString() == "mine" || 
        currentButton->property("buttonType").toString() == "revealed") {
        return;
    }

    // Reveals the current button tile by setting its property type to "revealed"
    currentButton->setProperty("buttonType", "revealed");

    // Gets the number of adjacent mines of the current button tile
    int adjacentMines = totalAdjacentMines(row, col);

    // If the current button tile has adjacent mines, it will display that number by calling the function "setNumOfAdjacentMinesIcon", passing that number along with the current button as parameters. Then, it will stop recursing in that direction
    if (adjacentMines > 0) {
        setNumOfAdjacentMinesIcon(row, col, adjacentMines, currentButton);
        return;
    } 

    // No adjacent mine tiles:
    else {
        
        // Set the current button's icon so that it displays a blank tile
        currentButton->setIcon(QIcon("../Assignment 1/assets/blank.png"));
        currentButton->setIconSize(QSize(25, 25));

        // Recursively reveals all 8 neighbors
        gridDFS(row - 1, col); // Up
        gridDFS(row + 1, col); // Down
        gridDFS(row, col - 1); // Left
        gridDFS(row, col + 1); // Right
        gridDFS(row - 1, col - 1); // Top Left
        gridDFS(row - 1, col + 1); // Top Right
        gridDFS(row + 1, col - 1); // Bottom Left
        gridDFS(row + 1, col + 1); // Bottom Right
    }
}

/**
* areAllNonMineRevealed():
* A function that is called whenever a non mine button tile has been clicked.
* It returns false if a non mine tile still has not been revealed by checking if each non mine button tile's property type has not been set to "revealed"
* It returns true if all the non mine tiles have been revealed 
*
* @return false Returns false if a non mine tile still has not been revealed
* @return true Returns true if all the non mine tiles have been revealed
*/
bool GridLogic::areAllNonMineRevealed() {
    for (int i = 0; i < numOfRows; i++) {
        for (int j = 0; j < numOfColumns; j++) {
            
            // Checks to see if a non mine tile still has not been revealed by checking if its property type has not been set to "revealed"
            if (buttons[i][j]->property("buttonType").toString() != "mine" && buttons[i][j]->property("buttonType").toString() != "revealed") {
                return false; // Not all non mine tiles have been revealed
            }
        }
    }
    
    return true; // All non mine tiles have been revealed
}

/**
* revealMines():
* A function that is called whenever a mine button tile is clicked (player has lost).
* It reveals all the hidden mines in the grid by looking for the mine tiles.
* It checks if each button tile's property type is "mine". If so, it then sets their icon to an image of a mine
*/
void GridLogic::revealMines() {
    
    for (int i = 0; i < numOfRows; i++) {
        for (int j = 0; j < numOfColumns; j++) {
            
            // Checks if each button tile's property type is "mine"
            if (buttons[i][j]->property("buttonType").toString() == "mine"){

                // Sets their icon to an image of a mine and sets its size to 25x25
                buttons[i][j]->setIcon(QIcon("../Assignment 1/assets/mine.png"));
                buttons[i][j]->setIconSize(QSize(25, 25)); 
            }
        }
    }
}

/**
* getNumOfAdjacentMines():
* A getter function that gets the total number of adjacent mines. It is only used for the initialization of "numOfAdjacentMines" in the constructor
*
* @return numOfAdjacentMines The total number of adjacent mines 
*/
int GridLogic::getNumOfAdjacentMines(){
    return numOfAdjacentMines;
}

/**
* setNumOfAdjacentMines():
* A setter function that sets the variable "numOfAdjacentMines" with a number
* It is used in the constructor for the initialization of the variable "numOfAdjacentMines".
* It is also used to set "numOfAdjacentMines" to 0 in the function "totalAdjacentMines()" for each button that is explored
*
* @param newNumOfAdjacentMines The new total number of adjacent mines 
*/
void GridLogic::setNumOfAdjacentMines(int newNumOfAdjacentMines){
    numOfAdjacentMines = newNumOfAdjacentMines;
}

/**
* restartGame():
* A public slot function that handles the event of clicking the "Try again?", or restart, button in either the loss or win pop up window
* It resets each button tile in the grid by setting the icon's to the default unrevealed icon and also setting each button's property type to "default"
* It also sets the "GridWindow" class's "numOfMines" variable to the copy made in the constructor since the "GridWindow" class's "numOfMines" variable gets decremented to 0, and it needs to be set back to its initialized value before restarting a game
* Then, it calls the "GridWindow" class's "setMineTiles" function, passing the copy's value in to randomize a new set of mine tiles in the grid
*/
void GridLogic::restartGame() {
    
    // Resets each button tile in the grid by setting the icon's to the default unrevealed icon and also setting each button's property type to "default"
    for (int i = 0; i < numOfRows; i++){
        for (int j = 0; j < numOfColumns; j++){
            buttons[i][j]->setIcon(QIcon("../Assignment 1/assets/minesweeper-square.png"));
            buttons[i][j]->setIconSize(QSize(25, 25));
            buttons[i][j]->setProperty("buttonType", "default");
        }
    }

    // 
    gridWindow->setMineTiles(numOfMines);
}

/**
* exitGame():
* A public slot function that handles the event of clicking the "Exit" button in either the loss or win pop up window
* It Successfully terminates the program.
*/
void GridLogic::exitGame() {
    exit(0); // Successfully terminates the program
}

/**
* ~GridLogic():
* A Destructor method that cleans up the allocated resources
*/
GridLogic::~GridLogic() {
    delete popUpLost;
    delete popUpWon;
}
