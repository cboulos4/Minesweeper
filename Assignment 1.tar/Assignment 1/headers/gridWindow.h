#ifndef GRID_WINDOW_H
#define GRID_WINDOW_H

/**
* Author: Christopher Boulos (cboulos4) (251267786)
* Date: 5/2/2025
* 
* gridWindow.h: 
* This is a header file that defines the implementation for the "GridWindow" class, which handles the Minesweeper grid's UI.
* It also manages the left and right click interactions with the buttons
*/

#include <QMainWindow>
#include <QPushButton>
#include <QGridLayout>
#include <QVector>
#include <QIcon>
#include <QVariant>
#include <QDebug>
#include <iostream>
#include <cstdlib> 
#include <ctime> 
#include "gridLogic.h" 
#include "rightClickButton.h"

class GridLogic;

class GridWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit GridWindow(QWidget *parent = nullptr); // Constructor function

    void setMineTiles(int numOfMines); // A function that randomly assigns 99 button tiles in the grid with the property type of "mine", overwriting their previous property type of "default", indicating that they now contain mines
 
    const QVector<QVector<QPushButton*>>& getButtons() const; // A Getter function that returns the 2D QVector array holding the QPushButtons pointers of the minesweeper grid
    int getNumOfRows() const; // A Getter method that returns the number of columns in the minesweeper grid.
    int getNumOfColumns() const; // A Getter method that returns the number of columns in the minesweeper grid.
    int getNumOfMines(); // A Getter method that returns the total number of tiles containing mines in the minesweeper grid.
    void setNumOfMines(int numOfMines); // A Setter method that sets the total number of mines on the grid.
 
    ~GridWindow(); // A Destructor method that cleans up the allocated resources

private:
    const int NUM_OF_ROWS; // The number of rows in the minesweeper grid
    const int NUM_OF_COLUMNS; // The number of columns in the minesweeper grid
    int numOfMines; // The total number of tiles containing mines in the minesweeper grid
    
    QVector<QVector<QPushButton*>> buttons; // A 2D array of QPushButton pointers, where a button represents a tile on the grid.

    int randomRow; // Holds a random row index of a button for setting a mine 
    int randomColumn; // Holds a random column index of a button for setting a mine 
    
    QWidget *centralWidget; // A pointer to the central widget holding the layout
    QGridLayout *gridLayout; // A pointer to the grid layout that holds all the buttons in the grid

    GridLogic *logic; // A pointer to the "GridLogic" class, which handles the minesweeper grid's logic

    int getRandomRow(); // A private getter function that returns a random row index
    int getRandomColumn(); // A private getter function that returns a random column index

signals:
    void buttonClicked(int row, int col); // A signal that is emitted when a button is either left or right clicked
};

#endif // GRID_WINDOW_H
