#ifndef GRID_LOGIC_H
#define GRID_LOGIC_H

/**
* Author: Christopher Boulos (cboulos4) (251267786)
* Date: 5/2/2025
*
* gridLogic.h: 
* This is a header file that defines the implementation for the "GridLogic" class, which handles the Minesweeper grid's logic.
* It also handles button clicks from the signals sent from the "GridWindow", "PopUpLost", and "PopUpWon" classes.
* It checks for adjacent mines, reveals tiles, and handles game outcomes (win or loss).
*/

#include <QObject>
#include <QPushButton>
#include <QVector>
#include <iostream>
#include "gridWindow.h"
#include "popUpLost.h"
#include "popUpWon.h"

class GridWindow;
class PopUpLost;
class PopUpWon;

class GridLogic : public QObject
{
    Q_OBJECT

public:
    explicit GridLogic(GridWindow *gridWindowPtr, QObject *parent = nullptr); // A constructor method that constructs a GridLogic object.
    ~GridLogic(); // A Destructor function that cleans up the allocated resources

private:
    int numOfRows; // The number of rows in the minesweeper grid
    int numOfColumns; // the number of columns in the minesweeper grid
    int numOfMines; // the number of hidden mines in the minesweeper grid
    int numOfAdjacentMines; // the number of mines that are adjacent to a specific button tile
    
    GridWindow *gridWindow; // A poitner to the GridWindow instance (the grid's main window UI)
    PopUpLost *popUpLost; // A pointer to the PopUpLost instance (the popup window that appears after clicking a mine (losing))
    PopUpWon *popUpWon; // A pointer to the PopUpWon instance (the popup window that appears after winning)

    QPushButton *clickedButton; // A pointer to the button tile that was just clicked
    QVector<QVector<QPushButton*>> buttons; // A 2D array of QPushButton pointers, where a button represents a tile on the grid.
    
    int totalAdjacentMines(int row, int col); // Checks if each tile adjacent to the clicked button tile contains a mine. It increments the "numOfAdjacentMines" variable by 1 for each adjacent tile that contains a mine
    void setNumOfAdjacentMinesIcon(int row, int col, int numOfAdjacentMines, QPushButton* button); // A funtion that sets the clicked button tile's icon to the number of adjacent tiles containing mines that it has
    void gridDFS(int row, int col); // It utilizes Depth First Search (DFS) to recursively check neighbouring button tiles of the clicked button tile, revealing them if they meet certain conditions
    bool areAllNonMineRevealed(); // A function that is called whenever a non mine button tile has been clicked. It checks if all non mine button tiles have been revealed
    void revealMines(); // A function that is called whenever a mine button tile is clicked (player has lost). It reveals all the hidden mines in the grid by looking for the mine tiles.

    int getNumOfAdjacentMines(); // A getter function that gets the total number of adjacent mines. It is only used for the initialization of "numOfAdjacentMines" in the constructor
    void setNumOfAdjacentMines(int newNumOfAdjacentMines); // A setter function that sets the variable "numOfAdjacentMines" with a number
    
public slots:
    void handleButtonClick(int row, int col); // This function handles the button clicking events ent from the GridWindow class whenever the player left clicks or right clicks a button tile
    void restartGame(); // A public slot function that handles the event of clicking the "Try again?", or restart, button in either the loss or win pop up window
    void exitGame(); // A public slot function that handles the event of clicking the "Exit" button in either the loss or win pop up window
};

#endif // GRID_LOGIC_H
