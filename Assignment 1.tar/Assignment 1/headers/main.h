#ifndef MAIN_H
#define MAIN_H

/**
* Author: Christopher Boulos (cboulos4) (251267786)
* Date: 5/2/2025
*
* main.h:
* This file is for declaring the main entry point for the application
*/

#include <QApplication>
#include "gridWindow.h" 
#include "gridLogic.h"

class GridWindow;

#endif // MAIN_H
