#ifndef POP_UP_LOST_H
#define POP_UP_LOST_H

/**
* Author: Christopher Boulos (cboulos4) (251267786)
* Date: 5/2/2025
*
* popUpLost.h:
* This is a header file that defines the implementation for the "PopUpLost" class, which handles the popup window's UI that appears when the player clicks on a mine.
* It also connects the button signals to their respective slots, and emitting signals for restarting or exiting the game to the "GridLogic" class
*/

#include <QDialog>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>

class PopUpLost : public QDialog {
    Q_OBJECT

public:
    explicit PopUpLost(QWidget *parent = nullptr); // A constructor method that sets up the loss dialog popup window.
    ~PopUpLost(); // A destructor used to clean up dynamically allocated memory

private:
    QVBoxLayout *layout; // A pointer to the vertical box layout that contains the message and buttons of the popup window
    QLabel *message; // A pointer to the Label widget that contains a message
    QPushButton *restartButton; // A pointer to the QPushButton to the "Try Again?" button in the pop up window
    QPushButton *exitButton; // A pointer to the QPushButton to the "Exit" button in the pop up window
    
signals:
    void restartGame(); // A signal emitted to the "GridLogic" class when the player chooses to restart the game
    void exitGame(); // A signal emitted to the "GridLogic" class when the player chooses to exit the game

private slots:
    void onRestartButtonClicked(); // A slot that is accessed when the "Try Again?" button in the pop up window that appears after losing is clicked.
    void onExitButtonClicked(); // A slot that is accessed when the "Exit" button in the pop up window that appears after losing is clicked.
};

#endif // POP_UP_LOST_H
