#ifndef RIGHT_CLICK_BUTTON_H
#define RIGHT_CLICK_BUTTON_H

/**
* Author: Christopher Boulos (cboulos4) (251267786)
* Date: 5/2/2025
*
* rightClickButton.h
* This class extends QPushButton to add custom behavior for mouse click, specifically right clicks.
*/

#include <QPushButton>
#include <QMouseEvent>

class RightClickButton : public QPushButton {
    Q_OBJECT

public:
    explicit RightClickButton(QWidget *parent = nullptr); // A constructor method that initializes the button
    ~RightClickButton(); // A destructor used to clean up dynamically allocated memory

protected:
    void mouseReleaseEvent(QMouseEvent *e) override; // Event handler for mouse release events.

signals:
    void rightClicked(); // Emitted when the right mouse button is clicked
    void clicked(QMouseEvent *e); // Emitted when the left mouse button is clicked. It is an overloaded version.
};

#endif // RIGHT_CLICK_BUTTON_H
