# Minesweeper

## How to run in Gaul:

1. Use the command `cd` to move to the "Assignment 1" directory.

2. When you are in the "Assignment 1" directory, run the command `qmake6 Minesweeper.pro` (You will need to run this command twice since ".qmake.stash" isn't supposed to be included in the submission).

3. Then, run the command `make`.

4. Finally, to run the program, run the command `./Minesweeper`.